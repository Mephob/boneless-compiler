package lab1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

import static lab1.Util.readSerFile;


public class Lexer {
    private int currentLine;
    private String currentState;

    //kao za konstante
    private final String NOVI_REDAK = "NOVI_REDAK";
    private final String UDJI_U_STANJE = "UDJI_U_STANJE";
    private final String VRATI_SE = "VRATI_SE";
    //vracam boolean tamo gdje provjeravam tako da moram negdje pohraniti
    //i int koji mi VRATI_SE predaje, tako da to cinim ovdje
    private int VRATI_PARAMETAR;

    private LexerData data;
    private List<ENKA> automata;

    public Lexer() throws IOException, ClassNotFoundException {
        this.currentLine = 1;
        this.data = readSerFile();

        List<String> states = data.getLexerStates();
        this.currentState = states.get(0);

        automata = spawnAutomata();

        this.VRATI_PARAMETAR = 0;

        testPrint();
    }

    private void testPrint() {
        System.err.println(data.getLexerStates().toString());
        System.err.println(data.getTokens().toString());
    }

    public List<ENKA> spawnAutomata() {
        List<LexerRule> ruleList = data.getLexerRules();
        List<ENKA> automataList = new ArrayList<>();

        for (LexerRule rule : ruleList) {
            ENKA automat = new ENKA(rule);
            automataList.add(automat);
        }
        return automataList;
    }

    public void readInput() {

        Scanner sc = new Scanner(System.in);
        LinkedList<Character[]> tokenList = new LinkedList<>();

        while (sc.hasNextLine()) {
            String line = sc.nextLine();
            line = line + "\n";
            char[] lineChar = line.toCharArray();
            int len = lineChar.length;

            //init variables
            int safeSpot = 0;
            int lookahead = 0;
            List<Character> candidate = new ArrayList<>();
            candidate.add(lineChar[0]);

            while(lookahead < len) {    //kada citamo novi red?
                if (candidate.isEmpty()) {
                    safeSpot = lookahead + 1;
                    if (lookahead == len) {
                        break;
                    }
                    lookahead++;
                    if (lookahead < len) {
                        candidate.add(lineChar[lookahead]);
                        continue;
                    }
                }

                List<Integer> flags = runAllAutomata(candidate);

                if (flags.contains(1)) {            //bar jedan automat je u prihvatljivom stanju - idi dalje
                    lookahead++;
                    if (lookahead < len) {
                        candidate.add(lineChar[lookahead]);
                    }

                    if (lookahead == len) {
                        boolean change = findActions(hyperbruh(candidate));

                        if (change) {
                            lookahead = safeSpot + VRATI_PARAMETAR;
                            candidate.clear();
                            candidate.add(lineChar[lookahead]);
                            continue;
                        }
                        candidate.clear();
                    }
                } else if (flags.contains(0)) {
                    lookahead++;

                    if (lookahead < len) {
                        candidate.add(lineChar[lookahead]);
                    }

                    if (lookahead == len) {
                        List<Character> tempCandidate = new ArrayList<>(candidate);
                        int goBack = 0;

                        while(true){
                            if(tempCandidate.size() == 0 || tempCandidate.size() == 1) break;
                            goBack++;
                            tempCandidate.remove(tempCandidate.size() - 1);
                            if(runAllAutomata(tempCandidate).contains(1)){
                                break;
                            } else {
                                continue;
                            }
                        }

                        if (runAllAutomata(tempCandidate).contains(1)) {
                            boolean changeInner = findActions(hyperbruh(tempCandidate));
                            lookahead -= goBack;

                            if (changeInner) {
                                lookahead = safeSpot + VRATI_PARAMETAR;
                                candidate.clear();
                                candidate.add(lineChar[lookahead]);
                                continue;
                            }
                            candidate.clear();
                        } else {
                            System.err.println("Izraz " + candidate.toString() + " u retku " + currentLine + " nije validan.");
                            System.err.println("Provodi se postupak oporavka od pogreske.");
                            lookahead++;
                            continue;
                        }
                    }
                    continue;
                } else {            //svi automati krepali
                    List<Character> tempCandidate = new ArrayList<>(candidate);
                    int goBack = 0;

                    while(true){
                        if (tempCandidate.size() < 2) {
                            break;
                        }
                        goBack++;

                        tempCandidate.remove(tempCandidate.size() - 1);
                        if(!runAllAutomata(tempCandidate).contains(1)){
                            continue;
                        } else {
                            break;
                        }
                    }

                    if (runAllAutomata(tempCandidate).contains(1)) {
                        boolean changeInner = findActions(hyperbruh(tempCandidate));
                        lookahead -= goBack;

                        if (changeInner) {
                            lookahead = safeSpot + VRATI_PARAMETAR;
                            candidate.clear();
                            candidate.add(lineChar[lookahead]);
                            continue;
                        }
                        candidate.clear();
                    } else {
                        System.err.println("Izraz " + candidate.toString() + " u retku " + currentLine + " nije validan.");
                        System.err.println("Provodi se postupak oporavka od pogreske.");
                        lookahead++;
                        continue;
                    }
                }
            }
        }
        sc.close();
    }

    private List<Integer> runAllAutomata(List<Character> candidate) {
        List<Integer> results = new ArrayList<>();

        StringBuilder sb = new StringBuilder();
        for (char c : candidate) {
            sb.append(c);
        }
        String currentString = sb.toString();

        for (ENKA automaton : automata) {
            results.add(automaton.run(currentString));
        }
        return results;
    }

    public String hyperbruh(List<Character> forsen) {
        StringBuilder sb = new StringBuilder();

        for (char c : forsen) {
            sb.append(c);
        }

        return sb.toString();
    }

    public boolean findActions(String input) {
        List<String> actionList = new ArrayList<>();
        String satisfiedRegex = "";

        for (ENKA automaton : automata) {
            if (automaton.getStateName().equals(currentState)) {

                //System.err.println(input);
                //System.err.println(currentState);

                int var = automaton.run(input);

                if (var == 1) {
                    actionList = automaton.getActionArgs();
                    satisfiedRegex = automaton.getRegEx();

                    //System.err.println("Usao u drugi za input: " + input);
                    if (!actionList.isEmpty()) {
                        //System.err.println("Postoje akcije za: " + input + " " + actionList.toString());
                    }

                    break;
                }
            }
        }

        if (actionList == null || actionList.isEmpty()) {
            System.err.println("Something wrong with my actions.");
        }

        boolean returnFlag = false;
        boolean hasVrati = false;
        int vratiPar = 0;

        for (String action : actionList) {
            String currentAction = action.trim();
            if (currentAction.contains("VRATI_SE")) {
                hasVrati = true;
                vratiPar = Integer.parseInt(currentAction.split(" ")[1]);
            }
        }

        for (String action : actionList) {
            String currentAction = action.trim();
            if (currentAction.equals("-")) {
                this.skip();
                continue;
            }

            if (!currentAction.contains(" ") && data.getTokens().contains(currentAction)
                    && !currentAction.equals(NOVI_REDAK)) {
                if(hasVrati){
                    this.addToUniformList(currentAction, input, vratiPar);
                } else {
                    this.addToUniformList(currentAction, input, 0);
                }

            } else if (currentAction.equals(NOVI_REDAK)) {
                currentLine++;
            } else {
                String[] parts = currentAction.split(" ");
                if (parts[0].equals(this.UDJI_U_STANJE)) {
                    this.changeState(parts[1]);
                } else {                        //nije udji_u_stanje nego vrati_se
                    returnFlag = true;
                    VRATI_PARAMETAR = Integer.parseInt(parts[1]);
                }
            }
        }
        return returnFlag;
    }

    private void skip() {
        //do nothing
    }

    private void addToUniformList(String outString, String input, int length) {
        StringBuilder sb;
        sb = new StringBuilder(outString).append(" ");

        sb.append(String.valueOf(currentLine)).append(" ");
        if (length < 1){
            sb.append(input);
        } else {
            sb.append(input.substring(0, length));
        }
        System.out.println(sb.toString());
    }

    private void changeState(String newState) {
        //System.err.println("Mijenjam stanje iz " + currentState + " u " + newState);
        this.currentState = newState;
    }
}